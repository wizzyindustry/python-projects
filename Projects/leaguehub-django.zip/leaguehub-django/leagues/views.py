from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import League, Team, Match
from .forms import LeagueForm, TeamForm
from .utils import generate_fixtures, calculate_table

def landing(request):
    if request.user.is_authenticated:
        return redirect("dashboard")
    return render(request, "landing.html")

def signup_view(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect("dashboard")
    else:
        form = UserCreationForm()
    return render(request, "auth.html", {"form": form, "is_login": False})

def login_view(request):
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            login(request, form.get_user())
            return redirect("dashboard")
    else:
        form = AuthenticationForm()
    return render(request, "auth.html", {"form": form, "is_login": True})

def logout_view(request):
    logout(request)
    return redirect("landing")

@login_required
def dashboard(request):
    leagues = League.objects.filter(owner=request.user).order_by("-created_at")
    if request.method == "POST":
        form = LeagueForm(request.POST)
        if form.is_valid():
            league = form.save(commit=False)
            league.owner = request.user
            league.save()
            return redirect("league_detail", pk=league.pk)
    else:
        form = LeagueForm()
    return render(request, "dashboard.html", {"leagues": leagues, "form": form})

@login_required
def delete_league(request, pk):
    league = get_object_or_404(League, pk=pk, owner=request.user)
    league.delete()
    messages.success(request, "League deleted.")
    return redirect("dashboard")

def league_detail(request, pk):
    league = get_object_or_404(League, pk=pk)
    is_owner = request.user.is_authenticated and request.user == league.owner
    teams = league.teams.order_by("created_at")
    matches = league.matches.select_related("home_team", "away_team").order_by("round", "id")
    table = calculate_table(teams, matches)
    rounds = {}
    for m in matches:
        rounds.setdefault(m.round, []).append(m)
    return render(request, "league_detail.html", {
        "league": league, "is_owner": is_owner, "teams": teams,
        "matches": matches, "table": table, "rounds": sorted(rounds.items()),
    })

@login_required
def add_team(request, pk):
    league = get_object_or_404(League, pk=pk, owner=request.user)
    if league.matches.exists():
        messages.error(request, "Cannot add teams after fixtures are generated.")
        return redirect("league_detail", pk=pk)
    if request.method == "POST":
        form = TeamForm(request.POST)
        if form.is_valid():
            team = form.save(commit=False)
            team.league = league
            team.save()
    return redirect("league_detail", pk=pk)

@login_required
def remove_team(request, pk, team_pk):
    league = get_object_or_404(League, pk=pk, owner=request.user)
    if league.matches.exists():
        messages.error(request, "Cannot remove teams after fixtures are generated.")
        return redirect("league_detail", pk=pk)
    Team.objects.filter(pk=team_pk, league=league).delete()
    return redirect("league_detail", pk=pk)

@login_required
def gen_fixtures(request, pk):
    league = get_object_or_404(League, pk=pk, owner=request.user)
    teams = list(league.teams.all())
    if len(teams) < 2:
        messages.error(request, "Need at least 2 teams.")
        return redirect("league_detail", pk=pk)
    league.matches.all().delete()
    team_map = {t.name: t for t in teams}
    for rnd, home_name, away_name in generate_fixtures(teams):
        Match.objects.create(
            league=league, round=rnd,
            home_team=team_map[home_name.name], away_team=team_map[away_name.name],
        )
    messages.success(request, "Fixtures generated!")
    return redirect("league_detail", pk=pk)

@login_required
def update_score(request, pk, match_pk):
    league = get_object_or_404(League, pk=pk, owner=request.user)
    match = get_object_or_404(Match, pk=match_pk, league=league)
    if request.method == "POST":
        try:
            h = int(request.POST.get("home_score", -1))
            a = int(request.POST.get("away_score", -1))
            if h < 0 or a < 0:
                raise ValueError
            match.home_score = h
            match.away_score = a
            match.played = True
            match.save()
        except (ValueError, TypeError):
            messages.error(request, "Invalid score.")
    return redirect("league_detail", pk=pk)
