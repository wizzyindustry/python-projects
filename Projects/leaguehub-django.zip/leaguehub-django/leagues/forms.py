from django import forms
from .models import League, Team, Match

class LeagueForm(forms.ModelForm):
    class Meta:
        model = League
        fields = ["name"]
        widgets = {"name": forms.TextInput(attrs={"class": "form-control", "placeholder": "League name"})}

class TeamForm(forms.ModelForm):
    class Meta:
        model = Team
        fields = ["name"]
        widgets = {"name": forms.TextInput(attrs={"class": "form-control", "placeholder": "Team name"})}

class ScoreForm(forms.Form):
    home_score = forms.IntegerField(min_value=0, widget=forms.NumberInput(attrs={"class": "form-control score-input"}))
    away_score = forms.IntegerField(min_value=0, widget=forms.NumberInput(attrs={"class": "form-control score-input"}))
