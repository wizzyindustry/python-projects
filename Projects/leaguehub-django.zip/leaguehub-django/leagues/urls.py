from django.urls import path
from . import views
urlpatterns = [
    path("", views.landing, name="landing"),
    path("auth/signup/", views.signup_view, name="signup"),
    path("auth/login/", views.login_view, name="login"),
    path("auth/logout/", views.logout_view, name="logout"),
    path("dashboard/", views.dashboard, name="dashboard"),
    path("dashboard/delete/<uuid:pk>/", views.delete_league, name="delete_league"),
    path("league/<uuid:pk>/", views.league_detail, name="league_detail"),
    path("league/<uuid:pk>/add-team/", views.add_team, name="add_team"),
    path("league/<uuid:pk>/remove-team/<uuid:team_pk>/", views.remove_team, name="remove_team"),
    path("league/<uuid:pk>/generate/", views.gen_fixtures, name="gen_fixtures"),
    path("league/<uuid:pk>/score/<uuid:match_pk>/", views.update_score, name="update_score"),
]
